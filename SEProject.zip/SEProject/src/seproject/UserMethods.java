/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seproject;

import seproject.Event;
import java.util.ArrayList;

/**
 *
 * @author forbe
 */
public class UserMethods {
    
    public static ArrayList<Event> eventList = new ArrayList<Event>();
    
  
    //creates event when given name, timespan, and description
    
    public ArrayList<Event> getTheList(){
        return eventList;
    }
    public void createEvent(String NAME, int TIME_SPAN, String DESCRIPTION){
        Event temp = new Event(NAME, TIME_SPAN, DESCRIPTION);
        eventList.add(temp);
        //test System.out.println("Name: " + NAME + " Time: "+ TIME_SPAN + " Description: " + DESCRIPTION + " ID: " + temp.getID());
        System.out.println("[ Event Created ]");
    }

    //can add failsafe for when nothing to remove
    //removes event when given ID
    public void removeEvent(int ID){
        for (int x = 0; x < eventList.size(); x++){
            if (eventList.get(x).getID() == ID){
                eventList.remove(x);
            }
        }
        System.out.println("[ Event Removed ]");
    }
    
    //can add failsafe for when trying to edit nothing
    //edits event when given description and ID
    public void editFirstEvent(String NAME, int TIME_SPAN, String DESCRIPTION){
        Event temp = new Event(NAME, TIME_SPAN, DESCRIPTION);
        eventList.set(0, temp);
        System.out.println("[ First Event Edited ]");
        //test System.out.println("New Description: " + DESCRIPTION);
    }
    public void editSecondEvent(String NAME, int TIME_SPAN, String DESCRIPTION){
        Event temp = new Event(NAME, TIME_SPAN, DESCRIPTION);
        eventList.set(1, temp);
        System.out.println("[ First Event Edited ]");
        //test System.out.println("New Description: " + DESCRIPTION);
    }
   public void editThirdEvent(String NAME, int TIME_SPAN, String DESCRIPTION){
        Event temp = new Event(NAME, TIME_SPAN, DESCRIPTION);
        eventList.set(2, temp);
        System.out.println("[ First Event Edited ]");
        //test System.out.println("New Description: " + DESCRIPTION);
    }
    
    public void listEvents(){
        System.out.println("[ Listing events ]: ");
        for (Event e: eventList){
            System.out.println(e.toString());
        }
    }
    
}
