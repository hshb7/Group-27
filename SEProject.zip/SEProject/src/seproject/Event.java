/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package seproject;

/**
 *
 * @author forbe
 */
public class Event {
    
    private String NAME;
    private int TIME_SPAN;
    private int ID;
    private static int counter = 1;
    private String DESCRIPTION;
    
    public Event(String NAME, int TIME_SPAN, String DESCRIPTION){
        this.NAME = NAME;
        this.TIME_SPAN = TIME_SPAN;
        this.DESCRIPTION = DESCRIPTION;
        this.ID = counter++;
    }
    
    public void setName(String NAME){
        this.NAME = NAME;
    }
    
    public void setTIME(int TIME_SPAN){
        this.TIME_SPAN = TIME_SPAN;
    }
    
    public void setDESCRIPTION(String DESCRIPTION){
        this.DESCRIPTION = DESCRIPTION;
    }
    
    public String getName(){
        return this.NAME;
    }
    
    public int getTIME(){
        return this.TIME_SPAN;
    }
    
    public String getDESCRIPTION(){
        return this.DESCRIPTION;
    }
    
    public int getID() {
        return this.ID;
    }
    
    @Override
    public String toString(){
        
        return ("Name: " + this.NAME + ", Timespan: " + this.TIME_SPAN + ", Description: " + this.DESCRIPTION + ", ID#: " + this.ID);
    }
}
